import React from 'react'
import { Header } from './Header'
import { CardFacebook } from './CardFacebook'

export function Facebook() {
  return (
    <>
      <CardFacebook/>
    </>
  )
}

