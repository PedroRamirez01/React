import React from 'react'
import { Header } from './Header'
import { CardTwitter } from './CardTwitter'

export function Twitter() {
  return (
    <>
        <CardTwitter/>
    </>
  )
}
