import React from 'react'
import { Header } from './Header'
import { CardHome } from './CardHome'

export function Home() {
  return (
    <>
      <CardHome/>
    </>
  )
}
