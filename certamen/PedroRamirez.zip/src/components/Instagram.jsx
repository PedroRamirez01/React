import React from 'react'
import { Header } from './Header'
import { CardInstagram } from './CardInstagram'

export function Instagram() {
  return (
    <>
        <CardInstagram/>
    </>
  )
}
