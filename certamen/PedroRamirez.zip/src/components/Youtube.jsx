import React from 'react'
import { Header } from './Header'
import { CardYoutube } from './CardYoutube'

export function Youtube() {
  return (
    <>
        <CardYoutube/>
    </>
  )
}
