import React from 'react'

export function Header() {
  return (
    <div className='titulo'>Automotris G2 | Pedro Ramírez</div>
  )
}
